<?php
/**
 * Stripe app controller
 *
 * Licensed under The MIT License
 * Redistributions of files must retain the above copyright notice.
 *
 * @copyright Copyright 2011, Jeremy Harris
 * @link http://42pixels.com
 * @package stripe
 * @license MIT License (http://www.opensource.org/licenses/mit-license.php)
 */

/**
 * StripeAppController
 *
 * @package stripe
*/
class StripeAppController extends AppController {

}
